# import smtplib as s
# ob = s.SMTP("smtp.gmail.com",587)
# ob.starttls()
# ob.login("janidali957@gmail.com", "ezhn lsti iccq fuhw")
# subject = "Testing Code"
# body = "ha bahye aur suna kya hal hay aur suna"
# message = "subject:{}\n\n{}".format(subject,body)
# print(message)
# # add = "abdulhanaaan123@gmail.com"
# add = "janidali957@gmail.com"
# ob.sendmail("techopak",add,message)
# print("done")
# ob.quit()

import pyotp
import random
import base64
import time
import sys
import subprocess
import hashlib
import secrets
import smtplib as s

# Function to clear the previous printed line
def clear_previous_line():
    sys.stdout.write('\033[F')  # Move cursor up one line
    sys.stdout.write('\033[K')  # Clear line

# Function to generate a new OTP using TOTP algorithm
def generate_new_otp(totp):
    new_otp = totp.now()
    return new_otp

# Function to get the MAC address
def get_mac_address():
    result = subprocess.run(["ipconfig", "/all"], capture_output=True, text=True)
    output = result.stdout
    lines = output.split("\n")
    for line in lines:
        if "Physical Address" in line:
            mac_address = line.split(":")[-1].strip()
            return mac_address
    return None

# Generate a random secret key and encode it in base32 using the MAC address
mac_address = get_mac_address()
if mac_address:
    # Generate OTP using TOTP algorithm with a time step of 4 seconds (for testing purposes)
    secret_key_seed = mac_address.encode('utf-8')  # Using MAC address as seed for secret key
    secret_key_bytes = secrets.token_bytes(20)  # 20 bytes = 160 bits

    # Derive secret key using PBKDF2-HMAC
    secret_key = hashlib.pbkdf2_hmac('sha1', secret_key_seed, secret_key_bytes, 100000)
    secret_key_base32 = base64.b32encode(secret_key).decode('utf-8')

    totp = pyotp.TOTP(secret_key_base32, interval=4)

    # Number of OTPs to generate (change as needed)
    num_otps = 5

    for i in range(num_otps):
        # Generate the initial OTP
        otp = generate_new_otp(totp)

        # Sending email with the OTP
        try:
            ob = s.SMTP("smtp.gmail.com", 587)
            ob.starttls()
            ob.login("janidali957@gmail.com", "ezhn lsti iccq fuhw")
            subject = "Your OTP"
            body = f"Your OTP is: {otp}"
            message = f"Subject: {subject}\n\n{body}"
            print(message)
            add = "janidali957@gmail.com"  # Change to recipient email address
            ob.sendmail("techopak", add, message)
            print("OTP sent successfully.")
        except Exception as e:
            print(f"Error sending OTP: {e}")
        finally:
            ob.quit()

        # Wait for 4 seconds before generating the next OTP
        time.sleep(4)

else:
    print("Failed to retrieve MAC address.")
