from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QTextEdit, QPushButton, QVBoxLayout, QMessageBox


class ReportIssueWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Report Issue")
        self.setGeometry(100, 100, 400, 300)

        self.issue_textedit = QTextEdit()
        self.report_button = QPushButton("Report Issue")
        self.report_button.clicked.connect(self.report_issue)

        layout = QVBoxLayout()
        layout.addWidget(QLabel("<h2>Report Issue</h2>"))
        layout.addWidget(QLabel("Describe the issue or fraudulent activity:"))
        layout.addWidget(self.issue_textedit)
        layout.addWidget(self.report_button)

        self.setLayout(layout)

    def report_issue(self):
        issue_description = self.issue_textedit.toPlainText()
        if issue_description.strip():
            QMessageBox.information(self, "Issue Reported", "Your issue has been reported successfully.")
            # Here you can implement backend logic to process the reported issue
        else:
            QMessageBox.warning(self, "Empty Issue", "Please describe the issue before reporting.")

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)

    helpdesk_widget = HelpdeskWidget()
    report_issue_widget = ReportIssueWidget()



    sys.exit(app.exec_())